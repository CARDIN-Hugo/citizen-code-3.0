#!/bin/bash
# Renomme le package d'une APK décompilée par apktool.
# Usage: rename_package.sh <dossier_decode> <nouveau.package.name>
set -euo pipefail

DECODED_DIR="$1"
NEW_PKG="$2"
MANIFEST="$DECODED_DIR/AndroidManifest.xml"

if [ ! -f "$MANIFEST" ]; then
  echo "Erreur : $MANIFEST introuvable."
  exit 1
fi

OLD_PKG=$(grep -o 'package="[^"]*"' "$MANIFEST" | head -1 | sed 's/package="//;s/"$//')
if [ -z "$OLD_PKG" ]; then
  echo "Erreur : impossible de détecter le package d'origine dans le manifeste."
  exit 1
fi

echo "Package d'origine détecté : $OLD_PKG"
echo "Nouveau package demandé   : $NEW_PKG"

if [ "$OLD_PKG" = "$NEW_PKG" ]; then
  echo "Le package est déjà celui demandé, rien à faire."
  exit 0
fi

OLD_PATH=$(echo "$OLD_PKG" | tr '.' '/')
NEW_PATH=$(echo "$NEW_PKG" | tr '.' '/')

echo "--- Étape 1/4 : remplacement du nom de package (forme pointée) dans le manifeste et les ressources texte ---"
grep -rlZ "$OLD_PKG" "$DECODED_DIR" --include="*.xml" --include="*.yml" 2>/dev/null \
  | xargs -0 -r sed -i "s/$OLD_PKG/$NEW_PKG/g" || true

echo "--- Étape 2/4 : déplacement des dossiers de code source (forme slash) ---"
for smalidir in "$DECODED_DIR"/smali*/; do
  [ -d "$smalidir" ] || continue
  if [ -d "${smalidir}${OLD_PATH}" ]; then
    mkdir -p "${smalidir}$(dirname "$NEW_PATH")"
    mv "${smalidir}${OLD_PATH}" "${smalidir}${NEW_PATH}"
    echo "Déplacé : ${smalidir}${OLD_PATH} -> ${smalidir}${NEW_PATH}"
  fi
done

echo "--- Étape 3/4 : mise à jour des références internes au code (forme slash) dans tous les fichiers smali ---"
find "$DECODED_DIR" -iname "*.smali" -print0 \
  | xargs -0 -r sed -i "s#$OLD_PATH#$NEW_PATH#g"

echo "--- Étape 4/4 : relevage du targetSdkVersion si trop bas (Android 15+ refuse d'installer en dessous de 24) ---"
CURRENT_TARGET=$(grep -o 'targetSdkVersion="[0-9]*"' "$MANIFEST" | grep -o '[0-9]*' || echo "")
if [ -n "$CURRENT_TARGET" ] && [ "$CURRENT_TARGET" -lt 24 ]; then
  echo "targetSdkVersion=$CURRENT_TARGET -> relevé à 24"
  sed -i "s/targetSdkVersion=\"$CURRENT_TARGET\"/targetSdkVersion=\"24\"/" "$MANIFEST"
else
  echo "targetSdkVersion déjà suffisant ($CURRENT_TARGET), inchangé."
fi

echo "Renommage terminé."
