# Renommeur de package APK (automatisé via GitHub Actions)

Ce dépôt recompile automatiquement n'importe quel fichier `.apk` déposé dans
`input/` avec le nom de package de ton choix, à chaque fois que tu pousses
(`push`) un changement. Tu n'as plus besoin de repasser par moi à chaque
fois : GitHub fait tourner la recompilation sur ses propres serveurs et te
donne le résultat à télécharger.

## Mise en place (à faire une seule fois)

1. Crée un dépôt GitHub vide (sans README).
2. Avec **GitHub Desktop** (recommandé, pas besoin de ligne de commande) :
   ouvre ce dossier comme nouveau dépôt local, fais un commit, puis
   "Publish repository" vers ton dépôt vide.

## Utilisation (à chaque fois que tu veux renommer un APK)

1. Supprime l'ancien `.apk` du dossier `input/` s'il y en a un, et dépose le
   nouveau fichier `.apk` à l'intérieur (n'importe quel nom, tant qu'il
   finit par `.apk`, et qu'il n'y en a qu'un seul à la fois).
2. Ouvre `input/new_package.txt` et écris le nom de package que tu veux
   (ex : `com.Tralalere.CitizenCode`), rien d'autre dans le fichier.
3. Fais un commit + push (via GitHub Desktop : écris un message, "Commit
   to main", puis "Push origin").
4. Va sur la page de ton dépôt sur github.com, onglet **Actions**. Un
   nouveau run "Renommer le package d'un APK" démarre automatiquement
   (cercle jaune = en cours, coche verte = terminé, croix rouge = erreur).
5. Une fois terminé (1 à 3 minutes), clique sur le run, puis tout en bas
   de la page dans la section **Artifacts**, télécharge `apk-renomme.zip`.
   Dedans se trouve ton APK, renommé et signé, prêt à installer.

## Important avant d'installer

- **Désinstalle toute version précédente** de l'appli sur ton téléphone
  avant d'installer le nouvel APK généré : chaque run génère une nouvelle
  clé de signature, et Android refuse de mettre à jour une appli si la
  signature a changé.
- Si Android affiche "Application non installée" sans détail et que le
  `targetSdkVersion` d'origine était très bas, l'outil le relève
  automatiquement à 24 (c'est ce qui a réglé ce problème la dernière
  fois) — mais ça ne couvre pas toutes les causes possibles.

## Limites à connaître

- Cet outil renomme le package (manifeste + code Java/Kotlin + ressources
  texte). Il ne touche pas au code natif (fichiers `.so`). Si l'appli
  d'origine plante à l'ouverture à cause d'un composant natif incompatible
  avec une version récente d'Android (comme on l'a vu avec VirtualXposed
  et VirtualApp), renommer le package ne réglera pas ce plantage — ce
  n'est pas un problème de nom de package mais de compatibilité profonde
  du code natif avec ton système.
- Fonctionne bien sur la plupart des APK classiques. Les APK fortement
  protégés/obfusqués (anti-tamper, chiffrement du dex) peuvent échouer à
  la recompilation.
